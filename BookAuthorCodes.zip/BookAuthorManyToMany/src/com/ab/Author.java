package com.ab;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name="bookAuthor_tbl")
public class Author {

	@Id
	private int authorId;
	private String authorName;
	@ManyToMany(fetch=FetchType.LAZY,mappedBy="author")
	private Set<Book> book=new HashSet<>();
	public int getAuthorId() {
		return authorId;
	}
	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public Set<Book> getBook() {
		return book;
	}
	public void setBook(Set<Book> book) {
		this.book = book;
	}
	
	/*public void addBook(Book book) {
		book.setAuthor(this);			
		this.getBook().add(book);*/
	}


