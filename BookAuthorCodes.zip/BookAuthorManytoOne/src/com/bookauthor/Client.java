package com.bookauthor;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;



public class Client {

	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		while(true){
		System.out.println("Enter your choice from the list below:\n1.Query all the books in db\n2.Query all books written by an author.\n3.List all books with given price\n4.List all author names for given book id\n");
		Scanner in = new Scanner(System.in);
		int ch=in.nextInt();
		switch(ch)
		{
		case 1:
			TypedQuery<Book> q=em.createQuery("from Book ", Book.class);
			
			
			List<Book> list=q.getResultList();
			
			for(Book bk:list)
			{
				System.out.println(bk.getBookIsbn()+" "+bk.getBookTitle()+" "+bk.getBookPrice()+" "+bk.getAuthor().getAuthorId()+" "+bk.getAuthor().getAuthorName());
			}
			break;
		case 2:
			System.out.println("Enter name of author:\n");
			String aname=in.next()+in.nextLine();
			TypedQuery<Book> qry=em.createQuery("from Book where author.authorName=?", Book.class);
			qry.setParameter(1,aname);
			List<Book> list1=qry.getResultList();
			
			for(Book bk:list1)
			{
				System.out.println(bk.getBookTitle()+"\n");
			}
			break;
		case 3:
			System.out.println("Enter the price:\n");
			int price=in.nextInt();
			TypedQuery<Book> qu=em.createQuery("from Book where bookPrice=?", Book.class);
			qu.setParameter(1,price);
			List<Book> list2=qu.getResultList();
			
			for(Book bk:list2)
			{
				System.out.println(bk.getBookTitle()+"\n");
			}
			break;
		case 4:
			System.out.println("Enter the bookid:\n");
			int isbn=in.nextInt();
			TypedQuery<Book> qur=em.createQuery("from Book where bookIsbn=?", Book.class);
			qur.setParameter(1,isbn);
			List<Book> list3=qur.getResultList();
			
			for(Book bk:list3)
			{
				System.out.println(bk.getAuthor().getAuthorName()+"\n");
			}
			break;
		
		default:
			System.out.println("Invalid Entry");
			break;
		}
		
		
		
	
		
		em.getTransaction().commit();
		
		em.close();
		factory.close();
	}
	}
}
