package com.bookauthor;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name="bAuthor_tbl")
public class Author {

	@Id
	private int authorId;
	private String authorName;
	@OneToMany(mappedBy="author",cascade=CascadeType.ALL)
	private Set<Book> book=new HashSet<>();
	public int getAuthorId() {
		return authorId;
	}
	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public Set<Book> getBook() {
		return book;
	}
	public void setBook(Set<Book> book) {
		this.book = book;
	}
	
	public void addBook(Book book) {
		book.setAuthor(this);			
		this.getBook().add(book);
	}
}
