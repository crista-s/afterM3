package com.soap.bean;

public class ProductBean
{
	private String productName;
	private int price;
	private int productId;
	public ProductBean(int i, String string, int j) {
		super();
	}
	public ProductBean(String productName, int price, int productId) {
		super();
		this.productName = productName;
		this.price = price;
		this.productId=productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	
	
}
