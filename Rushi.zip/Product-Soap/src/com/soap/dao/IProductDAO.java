package com.soap.dao;


import java.util.ArrayList;
import java.util.List;

import com.soap.bean.ProductBean;

public interface IProductDAO {
	public List<ProductBean> getAllProducts();
	public ProductBean getProducts(int id);
	public ProductBean addProducts(ProductBean country);
	public ProductBean deleteProducts(int id);
}
