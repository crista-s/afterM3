package com.soap.dao;

public class ProductDaoImpl {
	package com.cg.learning.dao;

	import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.soap.bean.ProductBean;
import java.util.ArrayList;
	import java.util.HashMap;
	import java.util.List;

	


	/**
	 * 
	 * @author yvalecha DAO class with operations like create, delete , fetch on the
	 *         HashMap
	 */
	public class CountryDAOImpl implements ICountryDAO {
		static HashMap<Integer, Country> productIdMap = CountryDB.getCountryIdMap();

		/**
		 * Fetching all details of countries
		 * 
		 * @return List<Country>
		 */
		public List<Country> getAllCountries() {
			List<Country> countries = new ArrayList<Country>(productIdMap.values());
			return countries;
		}

		/**
		 * Fetching single country details
		 * 
		 * @param id
		 * @return Country
		 */
		public Country getCountry(int id) {
			Country country = productIdMap.get(id);
			return country;
		}

		/**
		 * Creating a new Country
		 * 
		 * @param country
		 * @return Country
		 */
		public ProductBean addCountry(ProductBean country) {
			countryIdMap.put(country.getCountryId(), country);
			return country;
		}

		/**
		 * Updating an existing country
		 * 
		 * @param country
		 * @return Country
		 */
		public ProductBean updateCountry(ProductBean country) {
			if (country.getCountryId() <= 0)
				return null;
			countryIdMap.put(country.getCountryId(), country);
			return country;

		}

		/**
		 * Deleting an existing country
		 * 
		 * @param id
		 * @return Country
		 */
		public ProductBean deleteCountry(int id) {
			return countryIdMap.remove(id);
		}

	}

}
