package com.soap.staticdb;


	
	import java.util.HashMap;

import com.soap.bean.*;

	/**
	 * 
	 * @author shicrisrutha
	 * Static DB class, hosting country details in a HashMap
	 */
	public class ProductDB {
		static HashMap<Integer, ProductBean> productIdMap = getProductIdMap();
		
		static {
			if (productIdMap == null) {
				productIdMap = new HashMap<Integer, ProductBean>();
				ProductBean shirt = new ProductBean(1, "shirt", 1000);
				ProductBean toy = new ProductBean( 2,"toy", 200);
				ProductBean cream = new ProductBean(3, "cream", 800);
				
				productIdMap.put(1, shirt);
				productIdMap.put(2, toy);
				productIdMap.put(3, cream);
			
			}

		}
		/**
		 * This is a getter method of HashMap
		 * @return HashMap<Integer, Country>
		 */
		public static HashMap<Integer, ProductBean> getProductIdMap() {
			return productIdMap;
		}
	}


