package com.author.client;

import java.util.List;
import java.util.Scanner;

import com.author.bean.AuthorBean;
import com.author.exception.AuthorException;
import com.author.service.AuthorServiceImpl;
import com.author.service.IAuthorService;

public class ClientAuthor {

	public static void main(String[] args) {
		AuthorBean bean=new AuthorBean();
		IAuthorService authorService=new AuthorServiceImpl();
		System.out.println("Select your option:\n1.Add Author\n2.Delete Author\n3.Find Author\n4.Display all authors\n5.Exit");
		Scanner in=new Scanner(System.in);
		int ch=in.nextInt();
		
		switch(ch)
		{
		case 1:
			
			System.out.println("Enter the first name");
			String name=in.nextLine();
			in.next();
			bean.setAuthorFirstName(name);
			System.out.println("Enter the middle name");
			name=in.nextLine();
			in.next();
			bean.setAuthorMiddleName(name);
			System.out.println("Enter the last name");
		    name=in.nextLine();
		    
			bean.setAuthorLastName(name);
			
			System.out.println("Enter the phone number");
			int num=in.nextInt();
			
			bean.setAuthorPhone(num);
			
			try {
				int authourId=authorService.addAuthor(bean);
				System.out.println("The author has been inserted with authour id:"+authourId);
			} catch (AuthorException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			break;			
		case 2:
			
			System.out.println("Enter the authour id");
			int authorId=in.nextInt();
			try {
				bean=authorService.deleteAuthor(authorId);
				if(bean!=null){
				System.out.println("Record deleted!!\n The deleted record is:");
				System.out.println("Authour Id:"+bean.getAuthorId());
				System.out.println("Authour Name:"+bean.getAuthorFirstName()+bean.getAuthorMiddleName()+bean.getAuthorLastName());
				System.out.println("Authour Phone number:"+bean.getAuthorPhone());
			}
			else
			{
				System.out.println("Authour is not present");
			}
			} catch (AuthorException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;	
			
		case 3:

			System.out.println("Enter the authour id");
			int authId=in.nextInt();
			try {
				bean=authorService.findAuthor(authId);
				if(bean!=null){
				System.out.println("Author Details:");
				System.out.println("Authour Id:"+bean.getAuthorId());
				System.out.println("Authour Name:"+bean.getAuthorFirstName()+bean.getAuthorMiddleName()+bean.getAuthorLastName());
				System.out.println("Authour Phone number:"+bean.getAuthorPhone());
				}
				else
				{
					System.out.println("Authour is not present");
				}
			} catch (AuthorException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;	
		case 4:
			try {
				List list=authorService.viewAllAuthors();
				if(list!=null)
				{
					for(Object obj: list)
					{

						AuthorBean abean=(AuthorBean)obj;
						System.out.println(abean.getAuthorId()+"\t"+abean.getAuthorFirstName()+" "+abean.getAuthorMiddleName()+" "+abean.getAuthorLastName()+"\t"+abean.getAuthorPhone()+"\n");
					}
				}
			} catch (AuthorException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
			break;
		case 5:
			System.exit(0);
			
		}

	}

}
