package com.author.service;

import java.util.List;

import com.author.bean.AuthorBean;
import com.author.dao.AuthorDaoImpl;
import com.author.dao.IAuthorDao;
import com.author.exception.AuthorException;

public class AuthorServiceImpl implements IAuthorService {

	IAuthorDao authorDao=new AuthorDaoImpl();
	@Override
	public int addAuthor(AuthorBean author) throws AuthorException {
		return authorDao.addAuthor(author);
	}

	@Override
	public AuthorBean deleteAuthor(int authorId) throws AuthorException {
		return authorDao.deleteAuthor(authorId);
	}

	@Override
	public AuthorBean findAuthor(int authorId) throws AuthorException {
		return authorDao.findAuthor(authorId);
	}

	@Override
	public List<AuthorBean> viewAllAuthors() throws AuthorException {
		return authorDao.viewAllAuthors();
	}

	
}
