package com.author.exception;

public class AuthorException extends Exception {

	public AuthorException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AuthorException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
