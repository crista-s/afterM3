package com.author.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.author.bean.AuthorBean;

public class AuthorDaoImpl implements IAuthorDao {

	private EntityManager entityManager;
	

	public AuthorDaoImpl() {
		
		entityManager = JPAUtil.getEntityManager();
		
	}

	@Override
	public int addAuthor(AuthorBean author) {
		entityManager.getTransaction().begin();
		entityManager.persist(author);
		entityManager.getTransaction().commit();
		return author.getAuthorId();
	}

	@Override
	public AuthorBean deleteAuthor(int authorId) {
		entityManager.getTransaction().begin();//transaction boundary begins
		
		
		AuthorBean author=entityManager.find(AuthorBean.class, authorId);
		
		if(author== null)
		{
			return null;
		}
		else
		{
			entityManager.remove(author);
			entityManager.getTransaction().commit();
			return author;
			
		}
		
		
	}

	@Override
	public AuthorBean findAuthor(int authorId) {
		entityManager.getTransaction().begin();//transaction boundary begins
		
		
		AuthorBean author=entityManager.find(AuthorBean.class, authorId);
		entityManager.getTransaction().commit();
		
		if(author== null)
		{
			return null;
		}
		else
		{
			entityManager.getTransaction().commit();
			return author;
			
		}
		
	}

	@Override
	public List viewAllAuthors() {
		entityManager.getTransaction().begin();//transaction boundary begins
		
		Query qry=entityManager.createQuery("from AuthorBean");
		//or useQuery qry= em.createQuery("select e from Employee e");
		
		List list=qry.getResultList();
		
		
		entityManager.getTransaction().commit();//transaction is commited
		return list;
		
		

	}

}
